-----Subquery for finding salary greater than average salary

select * from Employees
where salary>(select avg(salary) from employees e1)

-----Correlated query for finding the Employee in each department 
--whose salary is less than the avg salary of the department

select * from employees e1
where e1.salary<(select avg(e2.salary)
				from employees e2 
				where e1.dept=e2.dept)


-----Details of Employees whose salary is minimum

Explain analyze select * from Employees e1
where salary=(select min(salary)
			from Employees where e1.dept=dept)

-----Using Data
select e1.dept,min(e1.salary) 
from Employees e1
join Employees e2
on e1.dept=e2.dept
group by e1.dept;

with cte as(select *,
DENSE_RANK() over(partition by dept order by Salary) as rn 
from Employees)
select * from cte where rn=1;