-----Stored Procedures
create table orders(
orerid int,
Productname varchar(100),
Costing float,
GST float
)

create or replace procedure sp_addorders(oid int,pname varchar(100),cost1 float)
language plpgsql
as $$
declare
 	gst float:=ceil(cost1*0.12);
begin 
insert into ORDERS values(oid,pname,cost1,gst);
raise notice 'Orders added Successfully';
end;$$

call sp_addorders(1,'Vada Pav',20)
call sp_addorders(2,'Misal',60)

select * from orders


-----Procedure to add two numbers
create or replace procedure sp_op(num1 float,num2 float)
language plpgsql
as $$
declare
addn float:=num1+num2;
sub float:=num1-num2;
mult float:=num1*num2;
begin
raise notice 'Addition Of Two Numbers is :%',addn;
raise notice 'Subtarction Of Two Numbers is :%',sub;
raise notice 'Multiplication Of Two Numbers is :%',mult;
end;$$

call sp_op(100,50)

-----Loops
create or replace procedure sp_loop(n int)
language plpgsql
as $$
begin
while (n>=0) loop
		raise notice 'Value= %',n;
		n:=n-1;

end loop;
end;$$

call sp_loop(5)

-----Factorial of a number
create or replace procedure sp_fact(num int)
language plpgsql
as $$
declare 
fact int:=1;
begin
for i in 1..num loop
fact:=fact*i;
end loop;
raise notice 'Factorial is: %',fact;
end;$$

call sp_fact(5)


-----Multiplication Table

create or replace procedure sp_table(num int)
language plpgsql
as $$
begin
for i in 1..10 loop
raise notice '% * % = %',num,i,num*i;
end loop;
end;$$

call sp_table(5);

-----Conditional Statements
create or replace procedure sp_grade(per float)
language plpgsql
as $$
declare
	grade varchar(20):=' ' ;

begin
if (per>=75) then
	grade:='Distinction';
elseif (per>=60 AND per < 75) then
	grade:='First Class';
elseif (per>=50 AND per < 60) then
	grade:='Second Class';
elseif (per>=35 AND per < 50) then
	grade:='Pass';
else
	grade:='Fail';

end if;
raise Notice 'Grade: %',grade;
end; $$

call sp_grade(67);

-----Student Marks table
create table Students(
Roll_No int,
SName varchar(30),
Eng_Marks int,
Sci_Marks int,
Math_Marks int,
Total int,
Percentage float,
Grade varchar(30)
)

create or replace procedure sp_marks(rollno int,sname varchar(100),eng int,scn int,math int)
language plpgsql
as $$
declare
 	total int:=eng+scn+math;
	percentage int:=total/3;
	grade varchar(20):=' ';
begin
  if (percentage>=75) then
	grade:='Distinction';
  elseif (percentage>=60 AND percentage < 75) then
	grade:='First Class';
  elseif (percentage>=50 AND percentage < 60) then
	grade:='Second Class';
  elseif (percentage>=35 AND percentage < 50) then
	grade:='Pass';
  else
	grade:='Fail';
end if; 
insert into Students values (rollno,sname,eng,scn,math,total,percentage,grade);
raise notice '%,%,%',total,percentage,grade;
end;$$

call sp_marks(1,'Rushikesh',70,67,78);
call sp_marks(2,'Akash',68,65,63);
call sp_marks(3,'Anushka',81,82,83);
call sp_marks(4,'Vishal',53,54,55);
call sp_marks(5,'Tejas',31,32,33);

select * from students;

call sp_table(717);