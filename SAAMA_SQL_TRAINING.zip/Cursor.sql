CREATE TABLE EMPLOYEES(
EMPID int,
EMPNAME varchar(100) NULL,
SALARY float NULL,
TAX float NULL,
DOJ date NULL,
DEPT varchar(100) NULL,
DESG varchar(100) NULL,
DEPTMANAGERNAME varchar(100) NULL,
DEPTLOCATION varchar(100) NULL);

INSERT into EMPLOYEES 
values
(1,'Akash',70000,2000,'2017-05-20','IT','Software Developer','Suresh','Pune'),
(2,'Akshay',69000,1900,'2017-07-14','IT','Architect','Suresh','Pune'),
(3,'Ashwin',77000,2100,'2017-09-14','IT','Architect','Suresh','Pune'),
(4,'Chinmay',88000,2900,'2017-09-10','HR','Manager','Anita','Mumbai'),
(5,'Debayan',65000,2100,'2017-10-18','HR','Executive','Anita','Mumbai'),
(6,'Mangesh',99000,2900,'2017-10-10','HR','Manager','Anita','Mumbai'),
(7,'Nikhil',56000,2100,'2017-07-18','HR','Executive','Anita','Mumbai'),
(10,'Sandeep',45000,460,'2017-07-25','IT','Software Developer','Suresh','Pune');

select * from Employees;

do 
$$
declare 
	cur_emp cursor for Select EMPID,EMPNAME from Employees;
	eid int;
	ename varchar(100);

begin
	open cur_emp;
	fetch next from cur_emp into eid,ename;
	loop
	Raise Notice 'EMPID=%,EMPNAME=%',eid,ename;
	fetch next from cur_emp into eid,ename;
	exit when not found;
	end loop;
end;
$$


