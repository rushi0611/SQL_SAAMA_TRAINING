-----Views
-------Simple View
select * from emp_view

insert into emp_view
values
(6,'Ketan','M',38000,4000,'Astraa','Snowflake Developer')

insert into emp
values
(7,'Anay','M',39000,3000,'LSCS','Databricks Engineer')

select * from emp;

-----Complex View
create view vw_orders as(
select s.shopid,s.sname,s.city,t.BillAmount,t.BDATE,f.fname  
from shopes s
join fooditems f 
on f.shopid=s.shopid
join transactions t
on t.foodid=f.foodid
)

select * from vw_orders;

----------Materialized view

create materialized view fc_mv as(
select s.shopid,s.sname,s.city,f.fname,c.cname,t.billamount,t.bdate
from shopes s
join customer c
on s.shopid=c.shopid
join fooditems f
on f.shopid=c.shopid
join Transactions t
on t.cid=c.cid
)

select * from fc_mv


select * from shopes
select * from fooditems
select * from customer
select * from transactions

-----------------------------

create materialized view mate_vw as (
select * from emp
)

insert into emp
values
(9,'Anushka','F',37000,4200,'LSCS','PySpark Developer')

refresh materialized view mate_vw;

select * from mate_vw;

---------Subquery
select f.fname,count(t.foodid)
from fooditems f
join transactions t
on f.foodid=t.foodid
group by f.fname
having count(t.foodid)>1
limit 1;

select * from transactions;
select * from transactions;

connect database Training_DB_SAAMA;
