CREATE TABLE EMPLOYEES(
EMPID int,
EMPNAME varchar(100) NULL,
SALARY float NULL,
TAX float NULL,
DOJ date NULL,
DEPT varchar(100) NULL,
DESG varchar(100) NULL,
DEPTMANAGERNAME varchar(100) NULL,
DEPTLOCATION varchar(100) NULL);
INSERT into EMPLOYEES VALUES
(1, 'AKASH', 70000, 2000, '2017-05-20', 'IT', 'SOFTWARE DEVELOPER', 'SURESH', 'PUNE'),
(2, 'AKSHAY', 69000, 1900, '2017-07-14', 'IT', 'ARCHITECT', 'SURESH', 'PUNE'),
(3, 'ASHWIN', 77000, 2100, '2017-09-14', 'IT', 'ARCHITECT', 'SURESH', 'PUNE'),
(4, 'CHINMAY', 88000, 2900, '2017-09-10', 'HR', 'MANAGER', 'ANITA', 'MUMBAI'),
(5, 'DEBAYAN', 65000, 2100, '2017-10-18' , 'HR', 'EXECUTIVE', 'ANITA', 'MUMBAI'),
(6, 'MANGESH', 99000, 2900, '2017-10-10', 'HR', 'MANAGER', 'ANITA', 'MUMBAI'),
(7, 'NIKHIL', 56000, 2100, '2017-07-18', 'HR', 'EXECUTIVE', 'ANITA', 'MUMBAI'),
(10, 'SANDEEP', 45000, 460,'2017-07-25', 'IT', 'SOFTWARE DEVELOPER', 'SURESH', 'PUNE');



-------------------------------------------------
EXECUTE THE QUERIES AND CREATE An EMPLOYEE TABLE IN
THE DATABASE.
---------------------------
1. WRITE A QUERY TO FIND THE details of employee having
the 3 rd Higher Salary from the table
--ANSWER:
SELECT * FROM EMPLOYEES ORDER BY SALARY DESC OFFSET 2 FETCH NEXT 1 ROWS ONLY;
--------------------------------------

------------------------------------------
2. WRITE A QUERY TO FIND THE employee having the
second lowest salary from the table.
--ANSWER:
SELECT * FROM EMPLOYEES ORDER BY SALARY  OFFSET 1 FETCH NEXT 1 ROWS ONLY;

-----------------------------------------
3. WRITE A QUERY TO FIND THE details of employee having
the 5 th &amp; 6 th Higher Salary from the table
--ANSWER:
SELECT * FROM EMPLOYEES ORDER BY SALARY DESC OFFSET 4 FETCH NEXT 2 ROWS ONLY;

--------------------------------------------------------
4. Write a query to find the details of employee having the
lowest salary in each department
--ANSWER:
SELECT * FROM EMPLOYEES WHERE SALARY IN(SELECT MIN(SALARY) FROM EMPLOYEES
GROUP BY DEPT);
-----------------------------------------------------------
5. Write a CTE to find the details of employee having the
4 th Highest salary
--ANSWER:
WITH Salaries AS
(
    SELECT 
	EMPID,EMPNAME,SALARY, ROW_NUMBER() OVER(ORDER BY SALARY DESC) AS RNK
    FROM 
       EMPLOYEES
)
SELECT
  EMPID,EMPNAME,SALARY
FROM
  Salaries
WHERE
   RNK = 4;
----------------------------------------------------------------
6. Write a query to find the details of employee having 2 nd
highest salary holder in each department.
--ANSWER:
WITH Salaries AS
(
    SELECT 
	EMPID,EMPNAME,SALARY,DEPT, ROW_NUMBER() OVER( PARTITION BY DEPT ORDER BY SALARY DESC) AS RNK
    FROM 
       EMPLOYEES
)
SELECT
  EMPID,EMPNAME,SALARY,DEPT
FROM
  Salaries
WHERE
   RNK = 2;
--------------------------------------------------
7. Write a stored procedure which will create two table
from the single table (One is the department table and
second is the employee table and create a relationship
between them). [Hint : Use temp tables if required)
--ANSWER:
DO $$
BEGIN 
	CREATE TEMP TABLE SingleTable(
	EMPNAME VARCHAR(255),
	SALARY NUMERIC(10,2),
	DEPTNAME VARCHAR(255)
	);
	INSERT INTO SingleTable(EMPNAME,SALARY,DEPTNAME) VALUES
	('JOHN',6000,'HR'),
	('NAMAN',8999,'IT');
	
	
	
	--DROP TABLE IF EXISTS DEPARTMENT CASCADE;
	CREATE TABLE DEPARTMENT(
	DEPTID SERIAL PRIMARY KEY,
	DEPTNAME VARCHAR(255) NOT NULL UNIQUE
	);
	--DROP TABLE IF EXISTS EMPLOYEE1;
	CREATE TABLE EMPLOYEE1(
	EMPID SERIAL PRIMARY KEY,
	EMPNAME VARCHAR(255) NOT NULL,
	SALARY NUMERIC(10,2) NOT NULL,
	DEPTID INT NOT NULL REFERENCES DEPARTMENT(DEPTID)
	);

	INSERT INTO DEPARTMENT(DEPTNAME)
	SELECT DISTINCT DEPTNAME FROM SingleTable;
	INSERT INTO EMPLOYEE1(EMPNAME,SALARY,DEPTNAME)
	SELECT
		ST.EMPNAME,
		ST.SALARY,
		ST.DEPTNAME
	FROM SingleTable ST
	JOIN DEPARTMENT D ON ST.DEPTNAME=D.DEPTNAME;
END$$;

------------------------------------------------

SELECT * FROM EMPLOYEES;
