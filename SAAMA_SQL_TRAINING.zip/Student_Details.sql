-----Creating table for triggers example
create table EMPEXP (EMPID int,EMPNAME varchar(100),SAL float,
DESIGNATION varchar(100))

-----Function for trigger
create or replace function fn_emptrg()
RETURNS TRIGGER
language plpgsql
as $$
Begin
 RAISE NOTICE 'EMPLOYEE DETAILS ADDED SUCCESSFULLY';

RETURN NEW;
END;$$

---Writing the trigger for insert data
create trigger TRG_AFINSER
AFTER INSERT ON EMPEXP
FOR EACH ROW EXECUTE PROCEDURE fn_emptrg();

(1,'Amit',20000,'Trainee'),
(2,'Akash',37000.67,'Senior Software Engineer');

-----AUDITING the TABLES
----Audit Table
create table EMPDETAILS_AUDIT (EMPID int,EMPNAME varchar(100),SAL float,DESIGNATION VARCHAR(100),
UPDATEDBY varchar(100),UPDATEDDATETIME timestamp);

-----Function for Audit Tbale
create or replace function fn_empaudits()
returns trigger
language plpgsql
as $$
begin
	insert into EMPDETAILS_AUDIT values(OLD.EMPID,OLD.EMPNAME,OLD.SAL,OLD.DESIGNATION,CURRENT_USER,NOW());
	RETURN NEW;
	end;$$

------Trigger for Update table
create or replace trigger trg_empaudits
before update on EMPEXP
for each row execute procedure fn_empaudits();

update EMPEXP
set SAL= 65000 ,DESIGNATION='ETL Developer' where empid=2;

select * from EMPDETAILS_AUDIT;

-----For delete and audit past data
create or replace trigger trg_del
after delete on EMPEXP
for each row execute procedure fn_empaudits();

delete from EMPEXP
where empname='Amit';

select * from EMPEXP;

select * from EMPDETAILS_AUDIT;

------Trigger Example
CREATE TABLE STUDENTS (
ROLLNO INT PRIMARY KEY,
ENGMARKS int,
SCNMARKS int,
MATHMARKS int
);


CREATE TABLE STUDENTDETAILS(
ROLLNO INT,
TOTALMARKS int,
PERCENTAGE float,
GRADE VARCHAR(100),
FOREIGN KEY(ROLLNO) REFERENCES STUDENTS(ROLLNO)
);


create or replace function student_trigger ()
returns trigger
language plpgsql
as $$
declare 
	tot int:=0;
	per float:=0;
	gra varchar:='';

begin
	tot:=NEW.ENGMARKS+NEW.SCNMARKS+NEW.MATHMARKS;
	per:=tot/3;
	
	if (per>=75 )then
		gra:='Distinction';
    elseif (per>60 AND per < 75) then
	    gra:='First Class';
    elseif (per>50 AND per < 60) then
	    gra:='Second Class';
    elseif (per >35 AND per < 50) then
	     gra:='Pass';
    else
	    gra:='Fail';
	end if;

	insert into STUDENTDETAILS values (NEW.ROLLNO,tot,per,
								gra );

	RETURN NEW;

end;$$

create or replace trigger trg_student
after insert on STUDENTS
for each row execute procedure student_trigger();

insert into STUDENTS values(1,56,76,56);

select * from STUDENTS

select * from STUDENTDETAILS;