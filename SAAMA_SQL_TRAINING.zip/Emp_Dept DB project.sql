CREATE TABLE DEPARTMENT
(
DEPT_ID INT PRIMARY KEY,
DEPT_NAME VARCHAR(100),
DEPT_LOCATION VARCHAR(100)
);

INSERT INTO DEPARTMENT VALUES(1,'IT','PUNE');
INSERT INTO DEPARTMENT VALUES(2,'HR','MUMBAI');
INSERT INTO DEPARTMENT VALUES(3,'ADMIN','MUMBAI');
INSERT INTO DEPARTMENT VALUES(4,'SECURITY','PUNE');
INSERT INTO DEPARTMENT VALUES(5,'FINANCE','MUMBAI');


---------------Employees
select * from department;
CREATE TABLE EMPLOYEES
(
EMP_ID INT PRIMARY KEY,
EMP_NAME VARCHAR(100),
JOB_NAME VARCHAR(100),
MANAGER_ID INT ,
Constraint mid_fk FOREIGN KEY(MANAGER_ID) REFERENCES EMPLOYEES(EMP_ID),
HIRE_DATE TIMESTAMP,
SALARY DECIMAL(10,2),
COMMISSION DECIMAL(7,2),
DEPT_ID INT ,
Constraint did_fk FOREIGN KEY(DEPT_ID) REFERENCES DEPARTMENT(DEPT_ID)
)


INSERT INTO EMPLOYEES VALUES (1,'SUNIL','MANAGER',NULL,'10/10/2018',60001,1000,1);
INSERT INTO EMPLOYEES VALUES (2,'KAPIL','MANAGER',NULL,'05/10/2018',80012,1000,2);
INSERT INTO EMPLOYEES VALUES (3,'SAMIR','CLERK',2,'10/10/2018',11000,1000,2);
INSERT INTO EMPLOYEES VALUES (4,'KRUTIKA','CLERK',2,'05/10/2018',12000,1000,2);
INSERT INTO EMPLOYEES VALUES (5,'YASIKA','CLERK',2,'10/10/2019',13000,5000,2);
INSERT INTO EMPLOYEES VALUES (6,'SONAL','CLERK',2,'05/10/2019',14000,6000,2);

-----Country
CREATE TABLE COUNTRY(COUNTRYID INT PRIMARY KEY,
COUNTRYNAME VARCHAR(100),
COUNTRYCAPITAL VARCHAR(100))
;

INSERT INTO COUNTRY VALUES(1,'INDIA','DELHI');

-----States
CREATE TABLE STATES(STATEID INT PRIMARY KEY,
STATENAME VARCHAR(100),
STATECAPITAL VARCHAR(100),
COUNTRYID INT,
FOREIGN KEY(COUNTRYID) REFERENCES COUNTRY(COUNTRYID));

INSERT INTO STATES VALUES(1,'MH','MUMBAI',1);

-----City
CREATE TABLE CITY(CITYID INT PRIMARY KEY,
CITYNAME VARCHAR(100),
STATEID INT,
FOREIGN KEY(STATEID) REFERENCES STATES(STATEID))
;

INSERT INTO CITY VALUES(1,'MUMBAI',1);
INSERT INTO CITY VALUES(2,'PUNE',1);


select * from EMPLOYEES;
select * from DEPARTMENT;
select * from Country;
Select * from states;
select * from city;


-----Join All the 5 tables
select e.Emp_id,e.Emp_Name,
e.Job_Name,c1.CityName,d.Dept_Location,d.Dept_Name
from Employees e
join Department d
on e.DEPT_ID=d.DEPT_ID
join City c1
on c1.CityName=d.Dept_Location
join States s
on c1.STATEID=s.STATEID 
join Country c
on c.COUNTRYID =s.COUNTRYID ;


----On Which Department how much employees according to city
select d.Dept_Name,c.cityname,count(Emp_Id) as Employee_Count
from Department d
join City c
on d.DEPT_LOCATION=c.CITYNAME 
join Employees e
on e.DEPT_ID=d.DEPT_ID
group by (d.Dept_Name,c.cityname);


-----CTE/SUBQUERY
WITH CTE AS
(select E.EMP_NAME,E.SALARY,D.DEPT_NAME ,RANK()
over(PARTITION BY D.DEPT_NAME order by E.SALARY) as RANKNO
FROM EMPLOYEES E
JOIN DEPARTMENT D
ON E.DEPT_ID=D.DEPT_ID)
SELECT * FROM CTE WHERE RANKNO=1;


-----Exception Handling
-----Divide by Zero Exception
create or replace procedure sp_calculations(n1 float,n2 float)
language plpgsql
as $$
declare 
	t float;
begin
	t:=n1/n2;
	raise notice 'total = %',round(t);
exception
	when others then
		raise notice 'Exception Details: %', SQLERRM; 
		raise notice 'Exception occured % at %',SQLSTATE,CURRENT_TIMESTAMP;
end;$$

call sp_calculations(10.55,1);

-----
create table EMPDETAILS (EMP_ID int primary key,EMPNAME VARCHAR(100) unique);


create or replace procedure sp_eh(eid int,ename varchar(100))
language plpgsql
as $$
begin
	insert into EMPDETAILS values (eid,ename);
	raise notice 'Data Inserted Successfully';
exception
	when others then
	raise notice 'Exception Details: %',SQLERRM;

end;$$

call sp_eh(1,'Rushikesh');
call sp_eh(2,'Rusihkesh');
call sp_eh (1,'Tejas');

-----Error tracing

create table ERRORLOGS(
ERRORID int generated always as identity (start with 1 increment by 1),
ERRORMESSAGE VARCHAR(2000),
ERRORSTATE VARCHAR(2000),
ERRORGENERATEDBY VARCHAR(2000),
ERRORDATETIME Timestamp
);

create or replace procedure sp_eh(eid int,ename varchar(100))
language plpgsql
as $$
begin
	insert into EMPDETAILS values (eid,ename);
	raise notice 'Data Inserted Successfully';
exception
	when others then
	raise notice 'Exception Details: %, %',SQLERRM,NOW();
	insert into ERRORLOGS  
	(ERRORMESSAGE,ERRORSTATE,ERRORGENERATEDBY,ERRORDATETIME)
	values(SQLERRM,SQLSTATE,CURRENT_USER,NOW());
end;$$

call sp_eh (3,'Tejas');

select * from ERRORLOGS;
select * from EMPDETAILS;

-----Handling Multiple Exceptions
create or replace procedure sp_calc(n1 int,n2 int)
language plpgsql
as $$
declare 
	t1 int;
	--t2 int;
begin
	begin
	t1:=n1/n2;
	raise notice 'total = %',round(t);
	exception
		when others then
			--raise notice 'Exception Details: %,%,%,% ',SQLERRM,SQLSTATE,CURRENT_USER,NOW(); 
	
	insert into ERRORLOGS (ERRORMESSAGE,ERRORSTATE,ERRORGENERATEDBY,ERRORDATETIME)
	values(SQLERRM,SQLSTATE,CURRENT_USER,NOW());
	
	end;
	t1:=n1+n2;
	raise notice 'Addition Is :%',t1;
end;$$


call sp_calc(6,0);
select * from errorlogs;

-----Output Parameters

create or replace procedure op_pm(n1 int,n2 int,out n3 int,out n4 int,out n5 int)
language plpgsql
as $$
begin
n3:=n1+n2;
n4:=n1-n2;
n5:=n1*n2;
raise notice 'Addition is: %',n3;
end;$$


do 
$$
declare
    t int ;
begin
    call op_pm(10,5,t);
    
end$$;

create table school(schoolid int primary key ,
school_name varchar(100) unique)

create table errorlogs(
ERRORID int generated always as identity (start with 1 increment by 1),
ERRORMESSAGE varchar(200),
ERRORSTATE varchar(100),
ERRORGENERATEDBY varchar(200),
ERRORTIME Timestamp
)


create or replace procedure school_sp(sid int,sname varchar(100))
language plpgsql
as $$
begin 
	insert into school 
	values (sid,sname);
	raise notice 'DATA INSERTED SUCCESSFULLY';

exception
	when others then 
		raise notice 'Exception Occurred';
		insert into ERRORLOGS(ERRORMESSAGE,ERRORSTATE,ERRORGENERATEDBY,ERRORTIME)
		values(SQLERRM,SQLSTATE,CURRENT_USER,NOW());

end;$$

select * from ERRORLOGS;
call school_sp(2,'Rushikesh');
