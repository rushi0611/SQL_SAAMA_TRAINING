CREATE TABLE EMPLOYEES(
EMPID int,
EMPNAME varchar(100) NULL,
SALARY float NULL,
TAX float NULL,
DOJ date NULL,
DEPT varchar(100) NULL,
DESG varchar(100) NULL,
DEPTMANAGERNAME varchar(100) NULL,
DEPTLOCATION varchar(100) NULL);

INSERT into EMPLOYEES 
values
(1,'Akash',70000,2000,'2017-05-20','IT','Software Developer','Suresh','Pune'),
(2,'Akshay',69000,1900,'2017-07-14','IT','Architect','Suresh','Pune'),
(3,'Ashwin',77000,2100,'2017-09-14','IT','Architect','Suresh','Pune'),
(4,'Chinmay',88000,2900,'2017-09-10','HR','Manager','Anita','Mumbai'),
(5,'Debayan',65000,2100,'2017-10-18','HR','Executive','Anita','Mumbai'),
(6,'Mangesh',99000,2900,'2017-10-10','HR','Manager','Anita','Mumbai'),
(7,'Nikhil',56000,2100,'2017-07-18','HR','Executive','Anita','Mumbai'),
(10,'Sandeep',45000,460,'2017-07-25','IT','Software Developer','Suresh','Pune');



-----First Value
select * ,
First_Value(Salary)over() 
From Employees;


select * ,
First_Value(Salary)over(partition by dept) 
From Employees;

-----Last Value
select * ,
Last_Value(Salary)over(partition by job_name) 
From Employees;

select * from Employees

-----Lead
select EMPID,EMPNAME,SALARY,TAX,DOJ,DEPT,DESG,
Lead(salary) over(order by SALARY)
from EMPLOYEES

-----Lag
select EMPID,EMPNAME,SALARY,TAX,DOJ,DEPT,DESG,
Lag(salary) over( partition by dept order by SALARY)
from EMPLOYEES

select *,NTILE(3) over() from Employees;

-----Ceil
select ceil(38.8) as ceil;

-----Floor
select floor(38.98) as floor;

-----Round
select round(39.50) as round;

-----Trunc
select trunc(39.28,1);

-----POWER,SQRT,LOG,DIV
Select  Round(SQRT(SALARY)::Decimal,2),Power(SALARY,1),
LOG(SALARY),DIV(SALARY::DECIMAL,TAX::DECIMAL)
from Employees;

-----Random
select RANDOM()

-----Percentage Of Each Employye Salary
select EMPID,EMPNAME,SALARY, 
(SALARY*100)/(select sum(salary) from Employees) as SALARY_PERCENTAGE
from Employees;


-----OR-----
select EMPID,EMPNAME,SALARY, 
(SALARY*100)/sum(salary) over() as SALARY_PERCENTAGE
from Employees;

with cte as(
select EMPID,EMPNAME,SALARY, 
(SALARY*100)/sum(salary) over() as SALARY_PERCENTAGE
from Employees
)
select EMPID,EMPNAME,SALARY,round(SALARY_PERCENTAGE)as rounded_salary from cte

select * from Employees;
-----Date Functions
select EMPID,EMPNAME,(NOW(),DOJ) from Employees;

-----Current Date
select current_date

-----Current_Time
select current_time


-----Extract
select extract(second from now())

-----DatePart
select date_part('year',Now())

----date_trunc
select date_trunc('hour',NOW())

select empid,empname,salary,dept,case
									when dept='IT' then cast(salary+salary*0.05 AS TEXT )
									when dept='HR' then cast(salary+salary*0.10 AS TEXT)
									else 'Enter Valid Department' end
									as Updated_SALARY
									from Employees;


select empid,empname,salary,dept,case
									when dept='IT' then salary+salary*0.05  
								    when dept='HR' then salary+salary*0.10 
									else 0 end
									as Updated_SALARY
									from Employees;
									
								   select * from Employees;



create table x1 (xid int,xname varchar(100))

insert into x1 values
(1,'Rushikesh'),
(1,'Rushikesh'),
(1,'Rushikesh')

delete from x1
where (xid,xname) not in(
select min(xid) ,xname 
from x1
group by xname
)
select * from x1