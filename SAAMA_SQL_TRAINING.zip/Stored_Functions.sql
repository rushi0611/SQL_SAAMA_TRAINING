-----Addition of function
create or replace function fn_add(n1 int,n2 int)
returns int
language plpgsql
as $$
declare 
	total int:=0;
begin
	total:=n1+n2;
	return total;
end;$$

select fn_add(10,20);

------
create or replace function sal_calc(sal float,days int)
returns float
language plpgsql
as $$
declare 
	pf int:=sal*0.12;
	leaves int:= (sal/30)*days;
	home_sal float:=0;
	tax int:=sal*0.05;
begin
	home_sal:=sal-(pf+leaves+tax);
	raise notice 'Home Salary is: ';
	return home_sal;
end;$$

select sal_calc(40000,3);

select emp_id,emp_name,job_name,sal_calc(salary,3)as inhand_salary from EMPLOYEES;


-----Table Level Functions
select * from EMPLOYEES;

create or replace function emp_func(ename varchar(30))
returns table(empno int,job varchar(100),hire Timestamp,sal numeric(10,2))
language plpgsql
as $$
begin
	return query (select emp_id,job_name,hire_date,salary from EMPLOYEES where emp_name=ename);
end; $$

select * from emp_func('SAMIR');