/*CREATE TABLE DEPARTMENT
(
DEPT_ID INT PRIMARY KEY,
DEPT_NAME VARCHAR(100),
DEPT_LOCATION VARCHAR(100)
);

INSERT INTO DEPARTMENT VALUES(1,'IT','PUNE');
INSERT INTO DEPARTMENT VALUES(2,'HR','MUMBAI');
INSERT INTO DEPARTMENT VALUES(3,'ADMIN','MUMBAI');
INSERT INTO DEPARTMENT VALUES(4,'SECURITY','PUNE');
INSERT INTO DEPARTMENT VALUES(5,'FINANCE','MUMBAI');


---------------Employees
select * from department;
CREATE TABLE EMPLOYEES
(
EMP_ID INT PRIMARY KEY,
EMP_NAME VARCHAR(100),
JOB_NAME VARCHAR(100),
MANAGER_ID INT ,
Constraint mid_fk FOREIGN KEY(MANAGER_ID) REFERENCES EMPLOYEES(EMP_ID),
HIRE_DATE TIMESTAMP,
SALARY DECIMAL(10,2),
COMMISSION DECIMAL(7,2),
DEPT_ID INT ,
Constraint did_fk FOREIGN KEY(DEPT_ID) REFERENCES DEPARTMENT(DEPT_ID)
)


INSERT INTO EMPLOYEES VALUES (1,'SUNIL','MANAGER',NULL,'10/10/2018',60001,1000,1);
INSERT INTO EMPLOYEES VALUES (2,'KAPIL','MANAGER',NULL,'05/10/2018',80012,1000,2);
INSERT INTO EMPLOYEES VALUES (3,'SAMIR','CLERK',2,'10/10/2018',11000,1000,2);
INSERT INTO EMPLOYEES VALUES (4,'KRUTIKA','CLERK',2,'05/10/2018',12000,1000,2);
INSERT INTO EMPLOYEES VALUES (5,'YASIKA','CLERK',2,'10/10/2019',13000,5000,2);
INSERT INTO EMPLOYEES VALUES (6,'SONAL','CLERK',2,'05/10/2019',14000,6000,2);
*/

create table Book(
    BookId int generated always as identity (start with 1 increment by 1),
	Title varchar(100),
	Author varchar(100),
	Price decimal(4,2)
)

do
$$
declare 
	i int:=1;
begin
	while (i<8000000) loop
		insert into Book(Title,Author,Price)
		values
		('Title1','Author1',10.45);
		i:=i+1;
	end loop;
end;$$

select * from Book;
select count(*) from Book;

-----Craeting Index
create index book_idx
on Book(BookId);

-----Updating Data using Indexes
update Book
set title='Brief History Of Tommorrow'
where BookId=26421817;

Explain Analyze select * from Book
where BookId=20995027;

-----Multi-Column Index
create unique index uniq_idx
on Book(BookId,title);

-----Unique Index
create unique index multicol_idx
on Book(BookId);

select * from Book
where BookId=26421817 or title='Brief History Of Tommorrow'

-----Partial Index
create index partial_index on book(BookId)
where title='Brief History Of Tommorrow';

-----Hash Index
create index hash_idx on book
using hash(BookId);

Explain Analyze select * from Book;
