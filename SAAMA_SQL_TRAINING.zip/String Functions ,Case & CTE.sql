-----Substr
select substring('Rushi',2,3)

-----Postition
select position ('Rus' in 'Rushikesh')

-----Length 
select length('Rushikesh')

-----Making First Letter as Capital
select initcap('eushi')

-----------CASE STATEMENT------
select *,(case 
			when dept='IT' then SALARY*2
			when dept='HR' then SALARY*0.5
			else 0
			end) as Bonus
from Employees


-----CTE 
with max_sal as(select *,dense_rank()over(partition by dept order by salary desc)as rnk
		from Employees 	
		) 
	select * from max_sal where rnk=1

-----CTE EXAMPLE---Insert Column from 1 tabble to another table

CREATE TABLE STUDENTS (
ROLLNO INT PRIMARY KEY,
ENGMARKS FLOAT,
SCNMARKS FLOAT,
MATHMARKS FLOAT
)

alter table students
rename RNO to ROLLNO;
CREATE TABLE STUDENTDETAILS(
ROLLNO INT,
TOTALMARKS FLOAT,
PERCENTAGE FLOAT,
GRADE VARCHAR(100),
FOREIGN KEY(ROLLNO) REFERENCES STUDENTS(ROLLNO)
)

insert into STUDENTS
values
(1,56,67,86),
(2,96,87,46),
(3,46,57,66)

insert into studentdetails
values
(1,219,89.5,'Distiction'),
(2,123,45.7,'Good'),
(3,240,78.5,'Excellent')

alter table Students add column Grade varchar(100)

update Students
set grade=s1.Grade from Studentdetails s1
where students.rollno=s1.rollno

select * from Students