-----Creating table for triggers example
create table EMPEXP (EMPID int,EMPNAME varchar(100),SAL float,
DESIGNATION varchar(100))

-----Function for trigger
create or replace function fn_emptrg()
RETURNS TRIGGER
language plpgsql
as $$
Begin
 RAISE NOTICE 'EMPLOYEE DETAILS ADDED SUCCESSFULLY';

RETURN NEW;
END;$$

---Writing the trigger for insert data
create trigger TRG_AFINSER
AFTER INSERT ON EMPEXP
FOR EACH ROW EXECUTE PROCEDURE fn_emptrg();

insert  into EMPEXP
values
(1,'Amit',20000,'Trainee');
(2,'Akash',37000.67,'Senior Software Engineer');

-----AUDITING the TABLES
----Audit Table
create table EMPDETAILS_AUDIT (EMPID int,EMPNAME varchar(100),SAL float,DESIGNATION VARCHAR(100),
UPDATEDBY varchar(100),UPDATEDDATETIME timestamp);

-----Function for Audit Tbale
create or replace function fn_empaudits()
returns trigger
language plpgsql
as $$
begin
	insert into EMPDETAILS_AUDIT values(OLD.EMPID,OLD.EMPNAME,OLD.SAL,OLD.DESIGNATION,CURRENT_USER,NOW());
	RETURN NEW;
	end;$$

------Trigger for Update table
create or replace trigger trg_empaudits
after update on EMPEXP
for each row execute procedure fn_empaudits();

update EMPEXP
set SAL= 45000 ,DESIGNATION='ETL Developer' where empid=1;




-----For delete and audit past data
create or replace trigger trg_del
after delete on EMPEXP
for each row execute procedure fn_empaudits();

delete from EMPEXP
where empname='Amit';

select * from EMPEXP;

select * from EMPDETAILS_AUDIT;

------Trigger Example
CREATE TABLE STUDENTS (
ROLLNO INT PRIMARY KEY,
ENGMARKS int,
SCNMARKS int,
MATHMARKS int
);


CREATE TABLE STUDENTDETAILS(
ROLLNO INT,
TOTALMARKS int,
PERCENTAGE float,
GRADE VARCHAR(100),
FOREIGN KEY(ROLLNO) REFERENCES STUDENTS(ROLLNO)
);


create or replace function student_trigger ()
returns trigger
language plpgsql
as $$
	declare 
		tot int:=NEW.ENGMARKS+NEW.SCNMARKS+NEW.MATHMARKS;
		gra varchar(100):='';
		per float:=0;
begin
	per:=tot/3;
	if (per>=75) then
    	gra:='Distinction';
    elseif (per>60 AND per < 75) then
	    gra:='First Class';
    elseif (per>50 AND per < 60) then
	    gra:='Second Class';
    elseif (per >35 AND per < 50) then
	     gra:='Pass';
    else
	    gra:='Fail';
	end if;

	insert into STUDENTDETAILS values (NEW.ROLLNO,tot,per,gra );

	RETURN NEW;

end;$$

create or replace trigger stu_trg
after insert on STUDENTS
for each row execute procedure student_trigger();

insert into students values(1,56,67,76);

insert into students values(2,56,67,76);

insert into students values (3,67,78,89);
-----Customer Table
Create table Customer(CUSTID int,CUSTOMERNAME varchar(100),
					   EMAIL varchar(100),MOBILE varchar(100))

Insert into Customer
values
(1,'ANIL','anil@yahoo.com','7448138466'),
(2,'SUNIL','sunil@yahoo.com','9876543210'),
(3,'KAPIL','kapil@yahoo.com','8097654321'),
(4,'TEJAS','tejas@yahoo.com','7890123456');

create table Customer_Audit (CUSTID int,CUSTOMERNAME varchar(100),EMAIL varchar(100)
,MOBILE VARCHAR(100),UPDATEDBY varchar(100),DELETEDDDATETIME timestamp);


create or replace function cust_trg()
returns trigger
language plpgsql
as $$
begin
	insert into Customer_Audit values(OLD.CUSTID,OLD.CUSTOMERNAME,OLD.EMAIL,OLD.MOBILE,CURRENT_USER,NOW());
	RETURN NEW;
	end;$$

create or replace trigger cust_trigger
after delete on Customer
for each row execute procedure cust_trg();

delete from Customer
where CUSTID=1;

select * from Customer_Audit;

------------------Exporting Students Data
select * from students
select * from studentdetails

create table school_data
as (select s.rollno,s.engmarks,s.scnmarks,s.mathmarks,sd.totalmarks,sd.percentage,sd.grade
	from Students s
	join StudentDetails sd
	on s.rollno=sd.rollno);


copy school_data to 'C:\data\school_data.csv' with header;


------Explain and Explain Analyze
Explain Analyze select s.rollno,s.engmarks,s.scnmarks,s.mathmarks,sd.totalmarks,sd.percentage,sd.grade
	from Students s
	join StudentDetails sd
	on s.rollno=sd.rollno;

create table products (pid int,pname varchar(200))


insert into products 
values(1,'Mango'),(2,'Banana'),(3,'Lassi')

create table prd_det(pid int,cat varchar(100))

insert into prd_det
values
(1,'Fruits'),
(3,'Cold drinks')

Explain Analyze with product_cte as(
Explain Analyze select p.pid,p.pname,pd.cat
from products p
left join prd_det pd
on p.pid=pd.pid)
select * from product_cte;


